#include <QApplication>
#include <QLocale>
#include <QTranslator>
#include <QFont>
#include "MainWindow.h"

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);

    // ── Мета-информация ──────────────────────────────
    app.setApplicationName("FairytaleGenerator");
    app.setApplicationDisplayName("Волшебный Сказочник");
    app.setOrganizationName("FairytaleApp");
    app.setApplicationVersion("1.0.0");

    // ── Русская локаль ───────────────────────────────
    QLocale::setDefault(QLocale(QLocale::Russian, QLocale::Russia));

    // Подгружаем системные переводы Qt (кнопки диалогов и т.д.)
    QTranslator qtTranslator;
    if (qtTranslator.load(
            QLocale::system(),
            "qt", "_",
            QApplication::applicationDirPath() + "/translations"
        )) {
        app.installTranslator(&qtTranslator);
    }

    // ── Шрифт по умолчанию ───────────────────────────
    QFont defaultFont;
#ifdef Q_OS_WIN
    defaultFont.setFamily("Segoe UI");
#elif defined(Q_OS_MAC)
    defaultFont.setFamily("SF Pro Text");
#else
    defaultFont.setFamily("Ubuntu");
#endif
    defaultFont.setPointSize(12);
    app.setFont(defaultFont);

    // ── Запуск главного окна ─────────────────────────
    MainWindow w;
    w.show();

    return app.exec();
}
