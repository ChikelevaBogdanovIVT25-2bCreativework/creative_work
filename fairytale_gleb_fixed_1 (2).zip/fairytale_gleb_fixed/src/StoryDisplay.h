#pragma once
#include <QWidget>
#include <QTimer>
#include "StoryData.h"

class QTextEdit;
class QLabel;
class QPushButton;
class QProgressBar;
class QTextToSpeech;
class QSlider;

class StoryDisplay : public QWidget {
    Q_OBJECT

public:
    explicit StoryDisplay(QWidget* parent = nullptr);

    // Показ состояний
    void showLoading();
    void showStory(const StoryData& story);
    void showError(const QString& message);

    // Печать (вызывается из MainWindow по сигналу printRequested)
    void printStory();

signals:
    void saveRequested();
    void newStoryRequested();
    void printRequested();

private slots:
    void onTypewriterTick();
    void onSpeakToggle();

private:
    void setupUi();
    void startTypewriter(const QString& text);
    void stopTypewriter();

    // Виджеты
    QLabel*       m_titleLabel;
    QTextEdit*    m_textEdit;
    QLabel*       m_statusLabel;
    QProgressBar* m_progress;
    QPushButton*  m_speakBtn;
    QPushButton*  m_saveBtn;
    QPushButton*  m_newBtn;
    QPushButton*  m_printBtn;
    QSlider*      m_speedSlider;

    // Typewriter
    QTimer*       m_typeTimer;
    QString       m_fullText;
    int           m_currentPos = 0;

    // TTS
    QTextToSpeech* m_tts;
    bool           m_speaking = false;

    StoryData      m_currentStory;
};
