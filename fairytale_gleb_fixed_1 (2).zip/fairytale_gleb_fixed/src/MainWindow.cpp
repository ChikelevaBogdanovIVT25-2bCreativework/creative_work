#include "MainWindow.h"
#include "ApiClient.h"
#include "Database.h"
#include "StoryDisplay.h"
#include "StoryWizard.h"
#include "SavedStoriesDialog.h"
#include "SettingsDialog.h"

#include <QStackedWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QSettings>
#include <QMessageBox>
#include <QStatusBar>
#include <QMenuBar>
#include <QDateTime>
#include <QFont>
#include <QApplication>
#include <QAction>

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent) {
    setWindowTitle("Волшебный Сказочник");
    setMinimumSize(800, 600);
    resize(900, 680);

    m_apiClient = new ApiClient(this);
    m_db        = new Database(this);
    m_db->open();

    setupUi();
    loadSettings();

    connect(m_apiClient, &ApiClient::storyReady,    this, &MainWindow::onStoryReady);
    connect(m_apiClient, &ApiClient::errorOccurred, this, &MainWindow::onApiError);
    connect(m_apiClient, &ApiClient::requestStarted, this, [=]() {
        m_storyDisplay->showLoading();
        showStoryScreen();
    });

    connect(m_storyDisplay, &StoryDisplay::saveRequested,     this, &MainWindow::onSaveStory);
    connect(m_storyDisplay, &StoryDisplay::newStoryRequested, this, &MainWindow::showMainMenu);
    connect(m_storyDisplay, &StoryDisplay::printRequested,    this, &MainWindow::onPrintStory);
}

MainWindow::~MainWindow() {
    saveSettings();
}

void MainWindow::setupUi() {
    qApp->setStyleSheet(R"(
        QMainWindow { background: #faf7ff; }
        QStatusBar  { background: #4a1fa6; color: white; font-size: 12px; }
        QMenuBar    {
            background: #4a1fa6; color: white;
            font-size: 13px; padding: 2px 4px;
        }
        QMenuBar::item:selected { background: #6a3fa6; }
        QMenu {
            background: white; color: #2d1a5e;
            border: 1px solid #d0c0f0; border-radius: 6px;
        }
        QMenu::item:selected { background: #ede0ff; }
    )");

    // Меню — используем QAction чтобы избежать deprecated перегрузок
    auto* fileMenu = menuBar()->addMenu("Файл");

    auto* newAction = new QAction("Новая сказка", this);
    newAction->setShortcut(QKeySequence::New);
    connect(newAction, &QAction::triggered, this, &MainWindow::onNewStory);
    fileMenu->addAction(newAction);

    auto* savedAction = new QAction("Сохранённые", this);
    savedAction->setShortcut(QKeySequence::Open);
    connect(savedAction, &QAction::triggered, this, &MainWindow::onOpenSaved);
    fileMenu->addAction(savedAction);

    fileMenu->addSeparator();

    auto* quitAction = new QAction("Выйти", this);
    quitAction->setShortcut(QKeySequence::Quit);
    connect(quitAction, &QAction::triggered, qApp, &QApplication::quit);
    fileMenu->addAction(quitAction);

    auto* settingsMenu = menuBar()->addMenu("Настройки");
    auto* settAction = new QAction("Настройки", this);
    connect(settAction, &QAction::triggered, this, &MainWindow::onSettings);
    settingsMenu->addAction(settAction);

    m_stack = new QStackedWidget(this);
    setCentralWidget(m_stack);

    // Страница главного меню
    m_menuPage = new QWidget;
    m_menuPage->setStyleSheet("QWidget { background: #faf7ff; }");
    auto* menuLayout = new QVBoxLayout(m_menuPage);
    menuLayout->setAlignment(Qt::AlignCenter);
    menuLayout->setSpacing(20);

    auto* logo = new QLabel("*", m_menuPage);
    logo->setAlignment(Qt::AlignCenter);
    logo->setStyleSheet("font-size: 72px;");

    auto* appTitle = new QLabel("Волшебный Сказочник", m_menuPage);
    appTitle->setAlignment(Qt::AlignCenter);
    appTitle->setStyleSheet(R"(
        font-size: 32px;
        font-weight: bold;
        color: #4a1fa6;
        font-family: 'Georgia', serif;
    )");

    auto* subtitle = new QLabel("Создавай сказки вместе с ребёнком", m_menuPage);
    subtitle->setAlignment(Qt::AlignCenter);
    subtitle->setStyleSheet("font-size: 16px; color: #9a80c0; margin-bottom: 20px;");

    auto makeMainBtn = [](const QString& text, const QString& bg) -> QPushButton* {
        auto* btn = new QPushButton(text);
        btn->setFixedSize(320, 60);
        btn->setStyleSheet(QString(R"(
            QPushButton {
                font-size: 17px;
                font-weight: bold;
                border: none;
                border-radius: 14px;
                background: %1;
                color: white;
            }
            QPushButton:hover { padding-left: 4px; }
        )").arg(bg));
        return btn;
    };

    auto* newBtn   = makeMainBtn("Создать новую сказку", "#7c4dbd");
    auto* savedBtn = makeMainBtn("Мои сказки",           "#27ae60");
    auto* settBtn  = makeMainBtn("Настройки",            "#7f8c8d");

    auto* hint = new QLabel(

        "Создавайте уникальные сказки вместе со своим ребёнком!", m_menuPage
    );
    hint->setAlignment(Qt::AlignCenter);
    hint->setStyleSheet("font-size: 13px; color: #b0a0d0; max-width: 400px;");
    hint->setWordWrap(true);

    menuLayout->addStretch(2);
    menuLayout->addWidget(logo);
    menuLayout->addWidget(appTitle);
    menuLayout->addWidget(subtitle);
    menuLayout->addSpacing(10);
    menuLayout->addWidget(newBtn,   0, Qt::AlignCenter);
    menuLayout->addWidget(savedBtn, 0, Qt::AlignCenter);
    menuLayout->addWidget(settBtn,  0, Qt::AlignCenter);
    menuLayout->addSpacing(20);
    menuLayout->addWidget(hint, 3, Qt::AlignCenter);
    menuLayout->addStretch(3);

    connect(newBtn,   &QPushButton::clicked, this, &MainWindow::onNewStory);
    connect(savedBtn, &QPushButton::clicked, this, &MainWindow::onOpenSaved);
    connect(settBtn,  &QPushButton::clicked, this, &MainWindow::onSettings);

    // Страница сказки
    m_storyPage    = new QWidget;
    auto* spLayout = new QVBoxLayout(m_storyPage);
    spLayout->setContentsMargins(0, 0, 0, 0);

    m_storyDisplay = new StoryDisplay(m_storyPage);
    spLayout->addWidget(m_storyDisplay);

    m_stack->addWidget(m_menuPage);
    m_stack->addWidget(m_storyPage);
    m_stack->setCurrentWidget(m_menuPage);

    statusBar()->showMessage("Добро пожаловать в Волшебный Сказочник!");
}

void MainWindow::showMainMenu() {
    m_storySaved = false;
    m_stack->setCurrentWidget(m_menuPage);
    statusBar()->showMessage("Готов создать новую сказку!");
}

void MainWindow::showStoryScreen() {
    m_stack->setCurrentWidget(m_storyPage);
}

void MainWindow::onNewStory() {
    if (!checkApiKey()) return;

    StoryWizard wizard(this);
    if (wizard.exec() != QDialog::Accepted) return;

    m_currentStory = wizard.storyData();
    m_currentStory.createdAt = QDateTime::currentDateTime();
    m_storySaved = false;

    m_apiClient->generateStory(m_currentStory);
}

void MainWindow::onOpenSaved() {
    SavedStoriesDialog dlg(m_db, this);
    connect(&dlg, &SavedStoriesDialog::storySelected,
            this, &MainWindow::onShowSavedStory);
    dlg.exec();
}

void MainWindow::onSettings() {
    SettingsDialog dlg(this);
    dlg.setApiKey(m_apiClient->apiKey());
    if (dlg.exec() == QDialog::Accepted) {
        m_apiClient->setApiKey(dlg.apiKey());
        saveSettings();
        statusBar()->showMessage("Настройки сохранены", 3000);
    }
}

void MainWindow::onStoryReady(const QString& title, const QString& text) {
    m_currentStory.title = title;
    m_currentStory.text  = text;
    m_storyDisplay->showStory(m_currentStory);
    statusBar()->showMessage(QString("Сказка «%1» готова!").arg(title));
}

void MainWindow::onApiError(const QString& error) {
    m_storyDisplay->showError(error);
    statusBar()->showMessage("Ошибка генерации. Проверьте настройки.", 5000);
}

void MainWindow::onSaveStory() {
    if (m_storySaved) {
        QMessageBox::information(this, "Уже сохранено",
            "Эта сказка уже сохранена в вашей коллекции!");
        return;
    }
    if (m_db->saveStory(m_currentStory)) {
        m_storySaved = true;
        QMessageBox::information(this, "Сохранено!",
            QString("Сказка «%1» сохранена в коллекцию!")
                .arg(m_currentStory.title));
        statusBar()->showMessage("Сказка сохранена!", 4000);
    } else {
        QMessageBox::warning(this, "Ошибка", "Не удалось сохранить сказку.");
    }
}

void MainWindow::onPrintStory() {
    m_storyDisplay->printStory();
}

void MainWindow::onShowSavedStory(const StoryData& story) {
    m_currentStory = story;
    m_storySaved   = true;
    m_storyDisplay->showStory(story);
    showStoryScreen();
    statusBar()->showMessage(QString("Открыта сказка «%1»").arg(story.title));
}

void MainWindow::loadSettings() {
    QSettings s("FairytaleApp", "FairytaleGenerator");
    m_apiClient->setApiKey(s.value("apiKey").toString());
}

void MainWindow::saveSettings() {
    QSettings s("FairytaleApp", "FairytaleGenerator");
    s.setValue("apiKey", m_apiClient->apiKey());
}

bool MainWindow::checkApiKey() {
    if (m_apiClient->hasApiKey()) return true;

    auto ans = QMessageBox::question(
        this,
        "API ключ не установлен",
        "Для генерации сказок нужен API ключ Yandex Cloud.\n\n"
        "Создайте сервисный аккаунт на console.yandex.cloud\n\n"
        "Открыть настройки прямо сейчас?",
        QMessageBox::Yes | QMessageBox::No
    );
    if (ans == QMessageBox::Yes) onSettings();
    return m_apiClient->hasApiKey();
}
