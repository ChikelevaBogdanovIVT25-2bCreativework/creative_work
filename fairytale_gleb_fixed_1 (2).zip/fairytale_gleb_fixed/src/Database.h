#pragma once
#include <QObject>
#include <QSqlDatabase>
#include <QList>
#include "StoryData.h"

class Database : public QObject {
    Q_OBJECT

public:
    explicit Database(QObject* parent = nullptr);
    ~Database();

    bool open();
    bool isOpen() const;

    // CRUD операции
    bool      saveStory(StoryData& story);      // story.id заполнится
    bool      deleteStory(int id);
    StoryData loadStory(int id);
    QList<StoryData> loadAllStories();          // Только метаданные

private:
    bool createTables();

    QSqlDatabase m_db;
    static const QString DB_FILE;
};
