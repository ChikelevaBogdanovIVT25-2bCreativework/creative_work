#include "StoryWizard.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLineEdit>
#include <QComboBox>
#include <QButtonGroup>
#include <QLabel>
#include <QPushButton>
#include <QRadioButton>
#include <QGroupBox>
#include <QFont>

// ═══════════════════════════════════════════
//  Вспомогательные стили
// ═══════════════════════════════════════════

static const QString STYLE_TILE = R"(
    QPushButton {
        font-size: 16px;
        padding: 12px 8px;
        border: 3px solid #e0d0ff;
        border-radius: 12px;
        background: #f8f4ff;
        color: #3a2070;
        min-width: 100px;
        min-height: 65px;
    }
    QPushButton:hover {
        background: #ede0ff;
        border-color: #9b72cf;
    }
    QPushButton[selected="true"] {
        background: #9b72cf;
        border-color: #6a3fa6;
        color: white;
    }
)";

static const QString STYLE_INPUT = R"(
    QLineEdit {
        font-size: 15px;
        padding: 8px 12px;
        border: 2px solid #c8b8f0;
        border-radius: 8px;
        background: white;
        color: #2d1a5e;
    }
    QLineEdit:focus { border-color: #7c4dbd; }
)";

static const QString STYLE_COMBO = R"(
    QComboBox {
        font-size: 14px;
        padding: 7px 10px;
        border: 2px solid #c8b8f0;
        border-radius: 8px;
        background: white;
        color: #2d1a5e;
        min-height: 35px;
    }
    QComboBox::drop-down { border: none; }
    QComboBox QAbstractItemView { font-size: 14px; }
)";

static const QString STYLE_RADIO = R"(
    QRadioButton {
        font-size: 14px;
        color: #3a2070;
        padding: 4px;
        spacing: 8px;
    }
    QRadioButton::indicator { width: 18px; height: 18px; }
)";

// ═══════════════════════════════════════════
//  StoryWizard
// ═══════════════════════════════════════════

QPushButton* StoryWizard::makeTileButton(const QString& emoji,
                                          const QString& label,
                                          QWidget* parent) {
    auto* btn = new QPushButton(emoji + "\n" + label, parent);
    btn->setStyleSheet(STYLE_TILE);
    btn->setCheckable(false);
    return btn;
}

StoryWizard::StoryWizard(QWidget* parent) : QWizard(parent) {
    setWindowTitle("Создаём сказку ✨");
    setWizardStyle(QWizard::ModernStyle);
    resize(620, 560);

    // Стиль самого мастера
    setStyleSheet(R"(
        QWizard { background: #faf7ff; }
        QWizard QLabel#qt_wizard_titleLabel {
            font-size: 20px;
            font-weight: bold;
            color: #4a1fa6;
        }
        QWizard QLabel#qt_wizard_subTitleLabel {
            font-size: 13px;
            color: #7a6090;
        }
        QPushButton#qt_wizard_nextButton,
        QPushButton#qt_wizard_finishButton {
            background: #7c4dbd;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            padding: 8px 20px;
            min-width: 100px;
        }
        QPushButton#qt_wizard_nextButton:hover,
        QPushButton#qt_wizard_finishButton:hover {
            background: #5e35b1;
        }
        QPushButton#qt_wizard_backButton,
        QPushButton#qt_wizard_cancelButton {
            background: #ede0ff;
            color: #4a1fa6;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            padding: 8px 20px;
        }
    )");

    m_welcomePage   = new WelcomePage(this);
    m_heroPage      = new HeroPage(this);
    m_placePage     = new PlacePage(this);
    m_adventurePage = new AdventurePage(this);

    addPage(m_welcomePage);
    addPage(m_heroPage);
    addPage(m_placePage);
    addPage(m_adventurePage);

    setButtonText(QWizard::NextButton,   "Дальше →");
    setButtonText(QWizard::BackButton,   "← Назад");
    setButtonText(QWizard::FinishButton, "Создать сказку! 🌟");
    setButtonText(QWizard::CancelButton, "Отмена");
}

StoryData StoryWizard::storyData() const {
    StoryData d;
    d.childName = m_welcomePage->childName();
    d.ageGroup  = m_welcomePage->ageGroup();
    d.hero      = m_heroPage->hero();
    d.heroTrait = m_heroPage->heroTrait();
    d.place     = m_placePage->place();
    d.problem   = m_adventurePage->problem();
    d.helper    = m_adventurePage->helper();
    d.magicItem = m_adventurePage->magicItem();
    d.ending    = m_adventurePage->ending();
    return d;
}

// ═══════════════════════════════════════════
//  WelcomePage
// ═══════════════════════════════════════════

WelcomePage::WelcomePage(QWidget* parent) : QWizardPage(parent) {
    setTitle("👋 Привет! Давай создадим сказку!");
    setSubTitle("Сначала скажи, как тебя зовут и сколько тебе лет");

    auto* layout = new QVBoxLayout(this);
    layout->setSpacing(18);

    // Имя
    auto* nameLabel = new QLabel("Как тебя зовут?", this);
    nameLabel->setStyleSheet("font-size: 15px; font-weight: bold; color: #3a2070;");
    m_nameEdit = new QLineEdit(this);
    m_nameEdit->setPlaceholderText("Введи своё имя...");
    m_nameEdit->setStyleSheet(STYLE_INPUT);
    connect(m_nameEdit, &QLineEdit::textChanged, this, &WelcomePage::completeChanged);

    // Возраст
    auto* ageLabel = new QLabel("Сколько тебе лет?", this);
    ageLabel->setStyleSheet("font-size: 15px; font-weight: bold; color: #3a2070;");

    auto* ageBox = new QGroupBox(this);
    ageBox->setStyleSheet("QGroupBox { border: 2px solid #d0c0f0; border-radius: 10px; padding: 10px; }");
    auto* ageLayout = new QHBoxLayout(ageBox);

    m_ageGroup = new QButtonGroup(this);

    struct AgeOpt { QString label; };
    QList<AgeOpt> ages = {
        {"🐣 3–5 лет"},
        {"🌱 6–8 лет"},
        {"🌟 9–12 лет"}
    };

    for (int i = 0; i < ages.size(); ++i) {
        auto* rb = new QRadioButton(ages[i].label, ageBox);
        rb->setStyleSheet(STYLE_RADIO);
        m_ageGroup->addButton(rb, i);
        ageLayout->addWidget(rb);
        if (i == 1) rb->setChecked(true); // По умолчанию 6-8
    }

    layout->addWidget(nameLabel);
    layout->addWidget(m_nameEdit);
    layout->addSpacing(10);
    layout->addWidget(ageLabel);
    layout->addWidget(ageBox);
    layout->addStretch();
}

bool WelcomePage::isComplete() const {
    return !m_nameEdit->text().trimmed().isEmpty();
}

QString WelcomePage::childName() const {
    return m_nameEdit->text().trimmed();
}

AgeGroup WelcomePage::ageGroup() const {
    int id = m_ageGroup->checkedId();
    if (id < 0) id = 1;
    return static_cast<AgeGroup>(id);
}

// ═══════════════════════════════════════════
//  HeroPage
// ═══════════════════════════════════════════

HeroPage::HeroPage(QWidget* parent) : QWizardPage(parent) {
    setTitle("🦸 Кто главный герой?");
    setSubTitle("Выбери из списка или придумай своего");

    auto* layout = new QVBoxLayout(this);
    layout->setSpacing(12);

    // Кнопки-плитки
    auto* grid = new QGridLayout;
    grid->setSpacing(8);

    struct HeroOpt { QString emoji; QString name; };
    QList<HeroOpt> heroes = {
        {"🐻", "Медведь"}, {"🦊", "Лисичка"}, {"🐺", "Волк"},
        {"🐰", "Зайчик"},  {"🐉", "Дракон"},  {"🧚", "Фея"},
        {"🧙", "Волшебник"},{"🦁", "Лев"},    {"🦄", "Единорог"}
    };

    for (int i = 0; i < heroes.size(); ++i) {
        auto* btn = new QPushButton(
            heroes[i].emoji + "\n" + heroes[i].name, this
        );
        btn->setStyleSheet(STYLE_TILE);
        btn->setFixedHeight(70);
        connect(btn, &QPushButton::clicked, this, [=]() {
            selectHero(heroes[i].name);
            if (m_selectedBtn) {
                m_selectedBtn->setProperty("selected", false);
                m_selectedBtn->style()->unpolish(m_selectedBtn);
                m_selectedBtn->style()->polish(m_selectedBtn);
            }
            btn->setProperty("selected", true);
            btn->style()->unpolish(btn);
            btn->style()->polish(btn);
            m_selectedBtn = btn;
        });
        grid->addWidget(btn, i / 3, i % 3);
    }

    // Поле своего героя
    auto* customLabel = new QLabel("Или напиши сам:", this);
    customLabel->setStyleSheet("font-size: 13px; color: #7a6090;");
    m_heroEdit = new QLineEdit(this);
    m_heroEdit->setPlaceholderText("Например: Принцесса Аврора...");
    m_heroEdit->setStyleSheet(STYLE_INPUT);
    connect(m_heroEdit, &QLineEdit::textChanged, this, &HeroPage::completeChanged);

    // Черта характера
    auto* traitLabel = new QLabel("Какой/какая он/она по характеру?", this);
    traitLabel->setStyleSheet("font-size: 14px; font-weight: bold; color: #3a2070;");
    m_traitCombo = new QComboBox(this);
    m_traitCombo->setStyleSheet(STYLE_COMBO);
    m_traitCombo->addItems({
        "Добрый и отзывчивый", "Смелый и отважный",
        "Хитрый и умный",       "Весёлый и озорной",
        "Любопытный и умный",   "Заботливый и нежный",
        "Сильный и честный"
    });

    layout->addLayout(grid);
    layout->addSpacing(6);
    layout->addWidget(customLabel);
    layout->addWidget(m_heroEdit);
    layout->addWidget(traitLabel);
    layout->addWidget(m_traitCombo);
}

void HeroPage::selectHero(const QString& name) {
    m_heroEdit->setText(name);
}

bool HeroPage::isComplete() const {
    return !m_heroEdit->text().trimmed().isEmpty();
}

QString HeroPage::hero() const { return m_heroEdit->text().trimmed(); }
QString HeroPage::heroTrait() const { return m_traitCombo->currentText(); }

// ═══════════════════════════════════════════
//  PlacePage
// ═══════════════════════════════════════════

PlacePage::PlacePage(QWidget* parent) : QWizardPage(parent) {
    setTitle("🌍 Где происходит сказка?");
    setSubTitle("Выбери волшебное место для приключения");

    auto* layout = new QVBoxLayout(this);
    layout->setSpacing(12);

    auto* grid = new QGridLayout;
    grid->setSpacing(8);

    struct PlaceOpt { QString emoji; QString name; };
    QList<PlaceOpt> places = {
        {"🌲", "Волшебный лес"}, {"🏰", "Замок"},       {"🌊", "Морское дно"},
        {"☁️", "Облака"},        {"🏔️", "Горы"},        {"🏜️", "Пустыня"},
        {"🌺", "Сад цветов"},    {"🌙", "Луна"},         {"🗺️", "Далёкое царство"}
    };

    for (int i = 0; i < places.size(); ++i) {
        auto* btn = new QPushButton(
            places[i].emoji + "\n" + places[i].name, this
        );
        btn->setStyleSheet(STYLE_TILE);
        btn->setFixedHeight(70);
        connect(btn, &QPushButton::clicked, this, [=]() {
            selectPlace(places[i].name);
            if (m_selectedBtn) {
                m_selectedBtn->setProperty("selected", false);
                m_selectedBtn->style()->unpolish(m_selectedBtn);
                m_selectedBtn->style()->polish(m_selectedBtn);
            }
            btn->setProperty("selected", true);
            btn->style()->unpolish(btn);
            btn->style()->polish(btn);
            m_selectedBtn = btn;
        });
        grid->addWidget(btn, i / 3, i % 3);
    }

    auto* customLabel = new QLabel("Или придумай своё место:", this);
    customLabel->setStyleSheet("font-size: 13px; color: #7a6090;");
    m_placeEdit = new QLineEdit(this);
    m_placeEdit->setPlaceholderText("Например: Подводная пещера...");
    m_placeEdit->setStyleSheet(STYLE_INPUT);
    connect(m_placeEdit, &QLineEdit::textChanged, this, &PlacePage::completeChanged);

    layout->addLayout(grid);
    layout->addSpacing(6);
    layout->addWidget(customLabel);
    layout->addWidget(m_placeEdit);
    layout->addStretch();
}

void PlacePage::selectPlace(const QString& name) {
    m_placeEdit->setText(name);
}

bool PlacePage::isComplete() const {
    return !m_placeEdit->text().trimmed().isEmpty();
}

QString PlacePage::place() const { return m_placeEdit->text().trimmed(); }

// ═══════════════════════════════════════════
//  AdventurePage
// ═══════════════════════════════════════════

AdventurePage::AdventurePage(QWidget* parent) : QWizardPage(parent) {
    setTitle("⚡ Какое приключение ждёт героя?");
    setSubTitle("Расскажи о проблеме, помощнике и концовке");

    auto* layout = new QVBoxLayout(this);
    layout->setSpacing(10);

    // Проблема
    auto* probLabel = new QLabel("❗ Главная проблема или задача:", this);
    probLabel->setStyleSheet("font-size: 14px; font-weight: bold; color: #3a2070;");
    m_problemEdit = new QLineEdit(this);
    m_problemEdit->setPlaceholderText("Например: нужно найти волшебный цветок...");
    m_problemEdit->setStyleSheet(STYLE_INPUT);
    connect(m_problemEdit, &QLineEdit::textChanged, this, &AdventurePage::completeChanged);

    // Помощник
    auto* helperLabel = new QLabel("🤝 Кто поможет герою?", this);
    helperLabel->setStyleSheet("font-size: 14px; font-weight: bold; color: #3a2070;");
    m_helperCombo = new QComboBox(this);
    m_helperCombo->setStyleSheet(STYLE_COMBO);
    m_helperCombo->addItems({
        "Старая мудрая Сова",     "Маленький смелый Мышонок",
        "Волшебная Рыбка",        "Добрая Фея",
        "Верный друг - пёс",        "Говорящее Дерево",
        "Загадочный Путник",      "Лесные эльфы",
        "Без помощника — сам!"
    });

    // Волшебный предмет (опционально)
    auto* magicLabel = new QLabel("🪄 Волшебный предмет (необязательно):", this);
    magicLabel->setStyleSheet("font-size: 13px; color: #7a6090;");
    m_magicEdit = new QLineEdit(this);
    m_magicEdit->setPlaceholderText("Например: золотой ключик, волшебная палочка...");
    m_magicEdit->setStyleSheet(STYLE_INPUT);

    // Концовка
    auto* endLabel = new QLabel("🎭 Какой будет конец?", this);
    endLabel->setStyleSheet("font-size: 14px; font-weight: bold; color: #3a2070;");

    auto* endBox = new QGroupBox(this);
    endBox->setStyleSheet("QGroupBox { border: 2px solid #d0c0f0; border-radius: 10px; padding: 8px; }");
    auto* endLayout = new QVBoxLayout(endBox);
    m_endingGroup = new QButtonGroup(this);

    QList<QString> endings = {
        "🎉 Счастливый — мечта исполнилась!",
        "📚 Поучительный — герой понял урок",
        "🚀 Открытый — впереди новые приключения"
    };
    for (int i = 0; i < endings.size(); ++i) {
        auto* rb = new QRadioButton(endings[i], endBox);
        rb->setStyleSheet(STYLE_RADIO);
        m_endingGroup->addButton(rb, i);
        endLayout->addWidget(rb);
        if (i == 0) rb->setChecked(true);
    }

    layout->addWidget(probLabel);
    layout->addWidget(m_problemEdit);
    layout->addWidget(helperLabel);
    layout->addWidget(m_helperCombo);
    layout->addWidget(magicLabel);
    layout->addWidget(m_magicEdit);
    layout->addWidget(endLabel);
    layout->addWidget(endBox);
}

bool AdventurePage::isComplete() const {
    return !m_problemEdit->text().trimmed().isEmpty();
}

QString    AdventurePage::problem()   const { return m_problemEdit->text().trimmed(); }
QString    AdventurePage::helper()    const { return m_helperCombo->currentText(); }
QString    AdventurePage::magicItem() const { return m_magicEdit->text().trimmed(); }
EndingType AdventurePage::ending()    const {
    int id = m_endingGroup->checkedId();
    if (id < 0) id = 0;
    return static_cast<EndingType>(id);
}
