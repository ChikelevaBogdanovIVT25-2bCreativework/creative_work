#pragma once
#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include "StoryData.h"

class ApiClient : public QObject {
    Q_OBJECT

public:
    explicit ApiClient(QObject* parent = nullptr);

    // Установить API ключ Yandex
    void setApiKey(const QString& key) { m_apiKey = key; }
    QString apiKey() const { return m_apiKey; }

    // Основной метод генерации
    void generateStory(const StoryData& data);

    // Проверка ключа
    bool hasApiKey() const { return !m_apiKey.isEmpty(); }

signals:
    void storyReady(const QString& title, const QString& text);
    void errorOccurred(const QString& error);
    void requestStarted();

private:
    QString buildPrompt(const StoryData& data) const;
    QString buildSystemPrompt(const StoryData& data) const;
    QString ageGroupStr(AgeGroup ag) const;
    QString endingTypeStr(EndingType et) const;

    QNetworkAccessManager* m_network;
    QString                m_apiKey;

    static const QString API_URL;
    static const QString MODEL;
};
